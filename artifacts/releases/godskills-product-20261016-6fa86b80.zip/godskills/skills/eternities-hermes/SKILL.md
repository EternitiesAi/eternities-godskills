---
name: eternities-hermes
description: Design and implement bounded automation or protocol integrations with explicit inputs, effects, failure handling, and close-out evidence.
---

# Eternities Hermes

Hermes is the automation and integration route. It turns a concrete workflow into inspectable steps, interfaces, fixtures, and a close-out state. It can write an authorized local implementation; it must still distinguish a prepared integration from an executed network or remote effect.

## Choose the route

- **Batch workflow** covers file-oriented command scripts, variables, loops, branching, exit handling, idempotence, and target scope.
- **Browser interaction** models context, selectors or element references, waits, navigation, download handling, failure recovery, and a close-out step.
- **Browser lifecycle** covers local or remote browser setup, screenshots, recordings, cleanup, and evidence retention.
- **Protocol-server generation** defines a Java or similar server boundary, typed tool/resource schemas, generated-file manifest, error contract, and local test fixture.
- **CLI or API bridge** separates read operations, configuration, invocation, authentication material, retries, and mutation.
- **Incremental stream intake** turns arbitrary response-byte chunks into complete framed records with bounded buffering and explicit partial-failure states; use the stream card in [methods.md](references/methods.md).
- **Remote-test coordination** builds a fixture matrix, prerequisites, skip rules, evidence capture, and cleanup without pretending that remote state changed.
- **Degraded integrations** distinguish an optional adapter from a required effect; use the failure-mode card in [methods.md](references/methods.md) when an absent backend or mock fallback could look like success.

## Conditional method references

Open only the matching reference for the selected task; ordinary integration work does not need to load either card.

- Repeated bounded reads of an authorized task feed: [cursor-paged task messages](references/cursor-paged-task-messages.md).
- Observing progress from an already-authorized local CLI child: [truthful CLI progress](references/truthful-cli-progress.md).

The cursor-paged task-message and local CLI-progress cards are DRAFTs. Hermes's existing `instruction-reviewed` entrypoint maturity does not review or certify these additions.

## Working method

1. Bind objective, target scope, expected result, authority, acceptance evidence, and termination or cleanup state.
2. Classify every step as read, local write, execution, network, remote mutation, or external write. Keep credentials and untrusted commands outside examples unless their authority and handling are explicit.
3. Define the input-to-output path and what counts as useful completion. Add retry, timeout, deduplication, partial-failure and recovery rules at the boundaries that need them. A pure local transformation does not need an operation journal or invented idempotency key. A batch that can partially write needs per-item outcomes and a safe replay rule; an external mutation with uncertain completion needs reconciliation before any replay.
4. For browser or protocol work, separate discovery from action and preserve the context that makes a reference valid. For integrations, define version, schema, authentication boundary, and failure modes before invocation.
5. Verify with an isolated fixture and inspect the real artifact or receipt. A fixture proves the declared contract, not live service availability, account state, or remote success.

For a file or record batch, enumerate the intended input set once and separate
each item's result from the batch's status. Keep unchanged, produced, failed and
unknown items distinguishable. Test a mixed-success batch and its rerun: completed
items must not be duplicated, failed independent items must remain recoverable,
and dependent steps must not run on missing outputs. Stage replacements when a
partial write could destroy the usable original. Reconcile an uncertain external
item before retrying it even if the rest of the batch can continue. Use a compact
result list for a small script; durable journals belong where interruption would
otherwise make effects ambiguous.

## Deliverable and finish

Return the requested implementation, workflow, matrix, refusal, or handoff with status, evidence, assumptions, performed effects, and cleanup. Finish at the declared close-out state. A deliberately continuing task needs an authorized owner or scheduler, observable running state, bounded resources, and a stop policy; never imply background work from a plan or leave an unowned loop. Preserve sessions the user wants to keep and report any cleanup still unresolved.
