# Godskills directory

Search metadata first; open the selected skill, then only its needed references. Relationships suggest collaboration, not mandatory loading. All entries are instruction-reviewed; this is not performance qualification.

For smaller bundled methods and their separate review/execution states, use the [selected method directory](METHODS.v1.md).

## agent-workflows

- [completeness-and-consistency-audit](skills/completeness-and-consistency-audit/SKILL.md): Trace declared obligations to actual artifacts, expose omissions and contradictions, and repair material dependencies within a finite coverage boundary.
- [eternities-omnibus](skills/eternities-omnibus/SKILL.md): Navigate the universal pack catalog offline with deterministic matching, explanations, stable tie-breaking, and explicit coverage gaps.
- [long-horizon-work-continuity](skills/long-horizon-work-continuity/SKILL.md): Preserve an authorized objective across milestones and interruption, reconcile live sources and uncertain effects, and resume within ownership and resource limits.
- [sovereign-skill-refinery](skills/sovereign-skill-refinery/SKILL.md): Synthesize workflow sources into independently authored, provenance-backed, structurally checked capabilities with honest disposition.

## agriculture

- [agricultural-observation-and-trial](skills/agricultural-observation-and-trial/SKILL.md): Organize crop and soil observations into locally grounded hypotheses and small measurable trials, without universal amendment prescriptions.

## audio

- [audio-dsp-integrity-review](skills/audio-dsp-integrity-review/SKILL.md): Review audio DSP across realtime deadline, numeric, and signal-graph lanes with exact findings, remediation, verification, and proof boundaries. Specialist of eternities-orpheus.
- [deterministic-video-composition-and-rendering](skills/deterministic-video-composition-and-rendering/SKILL.md): Compose and render seekable frame-based video with frozen fonts and assets, exact cue clocks, recoverable jobs and verification of the encoded artifact. Specialist of eternities-orpheus.
- [eternities-orpheus](skills/eternities-orpheus/SKILL.md): Create provenance, transcription, alignment, timeline, and reviewable local media artifacts from supplied audio.
- [portable-speech-chunk-alignment](skills/portable-speech-chunk-alignment/SKILL.md): Prepare multilingual speech chunks with pronunciation decisions, Unicode-safe boundaries and traceable text-to-audio lineage, including partial or cancelled output. Specialist of eternities-orpheus.

## automation

- [browser-automation-state-and-verification](skills/browser-automation-state-and-verification/SKILL.md): Complete browser interactions with durable session identity, fresh target references, observable transitions, verified artifacts and uncertain-submission reconciliation. Specialist of eternities-hermes.
- [eternities-hermes](skills/eternities-hermes/SKILL.md): Design and implement bounded automation, browser, protocol, CLI, and test integrations with explicit effect and close-out evidence.
- [structured-output-contracts](skills/structured-output-contracts/SKILL.md): Validate machine-consumed records and model JSON with schemas, source-bound IDs, governed vocabularies, relationship checks and truthful failure states. Specialist of eternities-hermes.

## business

- [customer-support-triage-and-resolution](skills/customer-support-triage-and-resolution/SKILL.md): Handle support issues through evidence-based triage, safe troubleshooting, truthful customer updates, focused escalation and explicit resolution states. Specialist of eternities-agora.
- [eternities-agora](skills/eternities-agora/SKILL.md): Traceable prospect, account, service, proposal, and client-report artifacts from reconciled evidence.
- [eternities-prometheus](skills/eternities-prometheus/SKILL.md): Route product-operations questions into evidence-led growth, analytics, customer insight, learning, planning, and delivery artifacts.
- [operating-cadence-and-decision-accountability](skills/operating-cadence-and-decision-accountability/SKILL.md): Design operating rules for founder or executive approval queues, scoped delegation, effective capacity, work-in-progress limits, and accountable exceptions. Specialist of eternities-prometheus.
- [pricing-and-packaging-experimentation](skills/pricing-and-packaging-experimentation/SKILL.md): Design price offers, charging units and package tiers; run pricing experiments and compare eligible pricing cohorts, contribution margin, and renewal effects. Specialist of eternities-beacon.
- [product-discovery-and-prioritization](skills/product-discovery-and-prioritization/SKILL.md): Choose evidence-relevant product opportunities and feasible portfolios with prerequisite closure, remaining effort, scarce capacity, uncertainty, cheap tests, and honest roadmap commitments. Specialist of eternities-prometheus.
- [structured-hiring-evaluation](skills/structured-hiring-evaluation/SKILL.md): Design role-specific hiring assessments, compare independent candidate evidence and diagnose dated recruiting funnels without proxy-based judgments. Specialist of eternities-prometheus.
- [vendor-evaluation-and-exit-planning](skills/vendor-evaluation-and-exit-planning/SKILL.md): Evaluate suppliers against mandatory requirements, observed performance and comparable total cost; plan vendor trials, contract renewal decisions, switching and credible exits. Specialist of eternities-prometheus.
- [venture-falsification-and-planning](skills/venture-falsification-and-planning/SKILL.md): Turn a venture thesis into source-labeled assumptions, staged falsification experiments, resource bounds, kill criteria, and decision records. Specialist of eternities-prometheus.

## data

- [bounded-verified-object-ingestion](skills/bounded-verified-object-ingestion/SKILL.md): Ingest a manifest-bound object set with identity and digest validation, quarantine, atomic staging, replay accounting, and rollback evidence. Specialist of eternities-atlas.
- [columnar-ingestion-rollup-and-query-layout-design](skills/columnar-ingestion-rollup-and-query-layout-design/SKILL.md): Design and compare columnar ingestion, partition, rollup, and query layouts from representative workload, lineage, late-data, and measurement evidence. Specialist of eternities-atlas.
- [eternities-atlas](skills/eternities-atlas/SKILL.md): Supplied tabular export reconciliation with column mapping, record deduplication, null semantics and row lineage. Build reproducible analytics, conditional connected-source evidence, finite trade-off frontiers, simulation-artifact handoffs, query planning, entity design and migration, synchronization, telemetry, experiment artifacts, and candidate eligibility, time-bound scorer revisions, and observed outcomes; the new extension remains DRAFT.
- [formula-preserving-workbook-engineering](skills/formula-preserving-workbook-engineering/SKILL.md): Change spreadsheet packages while preserving formula lineage, names, links, calculation behavior, package structure, and rendered sheets. Specialist of eternities-daedalus.
- [geospatial-coordinate-integrity](skills/geospatial-coordinate-integrity/SKILL.md): Identify horizontal and vertical reference meaning, transform coordinates, and verify map alignment, distance units, height comparability and spatial output integrity. Specialist of eternities-atlas.
- [lazy-tabular-transformation-and-validation](skills/lazy-tabular-transformation-and-validation/SKILL.md): Build and validate lazy tabular plans with explicit schemas, invariants, inspected execution, bounded collection, and resource evidence. Specialist of eternities-atlas.
- [schema-migration-and-backfill-safety](skills/schema-migration-and-backfill-safety/SKILL.md): Migrate database schemas and transform live rows across mixed app versions, with resumable backfills, concurrent-write protection and recovery checks. Specialist of eternities-atlas.
- [terrain-watershed-analysis](skills/terrain-watershed-analysis/SKILL.md): Select elevation surfaces and verify terrain derivatives, hydrologic conditioning, stream thresholds, catchments and viewsheds with explicit unit and sensitivity evidence. Specialist of geospatial-coordinate-integrity.

## design

- [accessibility-audit-and-remediation](skills/accessibility-audit-and-remediation/SKILL.md): Audit and repair complete interface journeys with keyboard, assistive-technology, focus, error recovery, adaptation and motion evidence. Specialist of eternities-muse.
- [bounded-parametric-design-iteration](skills/bounded-parametric-design-iteration/SKILL.md): Improve an existing solved parametric design through isolated changes, solver-backed comparison, hard-constraint checks, and finite accept-or-rollback evidence. Specialist of eternities-forge.
- [eternities-muse](skills/eternities-muse/SKILL.md): Direct visual forensics, interface direction, operational data views, motion, accessibility, and rendered acceptance through coherent evidence.
- [imaginative-concept-development](skills/imaginative-concept-development/SKILL.md): Explore and develop distinct concept mechanisms under constraints, then select by declared criteria without confusing invention with fact.
- [interface-localization-and-bidirectionality](skills/interface-localization-and-bidirectionality/SKILL.md): Implement and verify locale-aware content, formatting, RTL/LTR layout, mixed-direction text, controls, accessibility, and human translation review. Specialist of eternities-muse.
- [motion-design-and-animation-engineering](skills/motion-design-and-animation-engineering/SKILL.md): Build purposeful interactive motion with easing, spring choreography, gesture retargeting, responsive layout, cancellation and reduced-motion acceptance. Specialist of eternities-muse.
- [scene-continuity-and-coverage](skills/scene-continuity-and-coverage/SKILL.md): Design storyboards and camera coverage on a shared scene timeline with expressive motion, coherent geography and continuity across edits. Specialist of eternities-muse.
- [user-research-and-usability-study](skills/user-research-and-usability-study/SKILL.md): Plan neutral interviews and usability studies, preserve real participant observations and turn bounded findings into testable product improvements. Specialist of eternities-prometheus.

## education

- [evidence-linked-learning-design](skills/evidence-linked-learning-design/SKILL.md): Design evidence-linked lessons, assessments, teaching handoffs and learner reports from observable goals and supplied achievement evidence.

## engineering

- [api-contract-design-and-evolution](skills/api-contract-design-and-evolution/SKILL.md): Design and evolve API contracts with directional consumer/provider compatibility, presence and null semantics, behavioral errors, scoped replay, concurrent writes, cursor consistency, and migration evidence. Specialist of eternities-daedalus.
- [api-rate-limit-recovery](skills/api-rate-limit-recovery/SKILL.md): Build protocol-aware retry behavior with idempotency, bounded backoff, cancellation, concurrency control, and terminal evidence. Specialist of eternities-daedalus.
- [bounded-service-shutdown](skills/bounded-service-shutdown/SKILL.md): Implement an idempotent shutdown lifecycle with admission fencing, active-work accounting, bounded drain, cleanup ordering, and clean-versus-forced evidence. Specialist of eternities-daedalus.
- [confirmed-destructive-reconstruction](skills/confirmed-destructive-reconstruction/SKILL.md): Stage and verify a recoverable destructive reconstruction with exact target binding, independent backup validation, postconditions, and rollback evidence. Specialist of eternities-phoenix.
- [eternities-architect](skills/eternities-architect/SKILL.md): Produce evidence-backed requirements, boundaries, alternatives, interfaces, failure behavior, and implementation handoffs.
- [eternities-daedalus](skills/eternities-daedalus/SKILL.md): Implement, refactor, integrate, migrate, configure, optimize, and verify bounded engineering changes with direct evidence.
- [eternities-forge](skills/eternities-forge/SKILL.md): Coordinate bounded planning, implementation, review, verification, recovery, and integration across consequential engineering work.
- [eternities-phoenix](skills/eternities-phoenix/SKILL.md): Diagnose failures, derive candidate evaluation cases from authorized interactions, and design reversible recovery with bounded evidence.
- [fp-ts-functional-refactoring](skills/fp-ts-functional-refactoring/SKILL.md): Refactor TypeScript into explicit typed transformations and effect edges while retaining runtime behavior, error identity, ordering, and cancellation. Specialist of eternities-daedalus.
- [git-change-integration-and-recovery](skills/git-change-integration-and-recovery/SKILL.md): Integrate and recover Git changes while preserving hunk ownership, separating HEAD/index/worktree state, verifying the reviewed tree and detecting destination ref races. Specialist of eternities-daedalus.
- [invariant-guard](skills/invariant-guard/SKILL.md): Turn algorithm contracts into independent bounded oracles, invariant checks, adversarial cases, minimized counterexamples, and honest proof limits. Specialist of eternities-daedalus.
- [native-mobile-interaction-testing](skills/native-mobile-interaction-testing/SKILL.md): Author and run version-aware React Native interaction tests with accessible queries, explicit async behavior, and clear device-evidence boundaries. Specialist of eternities-daedalus.
- [robotics-test-ladder](skills/robotics-test-ladder/SKILL.md): Build a staged robotics verification ladder from deterministic unit and property checks through replay, simulation, HIL, and field evidence. Specialist of eternities-daedalus.
- [semantic-implementation-diff](skills/semantic-implementation-diff/SKILL.md): Compare bounded implementations through normalized contracts, traces, state and effect observations, minimized divergences, and explicit unknowns. Specialist of eternities-daedalus.
- [service-observability-and-slo-design](skills/service-observability-and-slo-design/SKILL.md): Design and implement event-correct reliability indicators, telemetry coverage, error budgets and actionable burn alerts. Specialist of eternities-daedalus.
- [web-performance-optimization](skills/web-performance-optimization/SKILL.md): Reduce a reproducible web bottleneck through repeated baselines, causal isolation, one bounded change, and functional, visual, and variance checks. Specialist of eternities-daedalus.

## finance

- [cashflow-forecast-scenario-integrity](skills/cashflow-forecast-scenario-integrity/SKILL.md): Build time-bucketed cash forecasts with traceable settlement timing, explicit liquidity constraints and scenario changes tied to declared drivers. Specialist of financial-statement-reconciliation.
- [financial-statement-reconciliation](skills/financial-statement-reconciliation/SKILL.md): Reconcile reported financial statements, trace calculated ratios, and stress-test assumptions without inventing assurance or investment certainty.

## games

- [eternities-arcadia](skills/eternities-arcadia/SKILL.md): Connect game direction, imported 3D assets, runtime systems, player experience, accessibility, performance, and human release evidence.
- [procedural-world-generation-and-validation](skills/procedural-world-generation-and-validation/SKILL.md): Build reproducible procedural worlds with chunk boundary contracts, state-aware progression checks, persistent overlays, and bounded generation recovery. Specialist of eternities-arcadia.

## legal

- [jurisdiction-aware-contract-review](skills/jurisdiction-aware-contract-review/SKILL.md): Extract obligations and reconcile contract clauses against the user's goals while separating document facts from jurisdiction-dependent legal conclusions.

## marketing

- [app-store-discovery-experiments](skills/app-store-discovery-experiments/SKILL.md): Audit app-store discovery inputs and run bounded one-variable listing experiments with dated evidence, guardrails, and honest attribution limits. Specialist of eternities-beacon.
- [eternities-beacon](skills/eternities-beacon/SKILL.md): Turn market, offer, discoverability, conversion, lifecycle, and growth evidence into truthful measurable decisions.
- [measured-paid-creative-iteration](skills/measured-paid-creative-iteration/SKILL.md): Convert aggregate campaign observations into falsifiable creative variants, precommitted metrics, guardrails, and a controlled experiment decision. Specialist of eternities-beacon.

## memory

- [approval-bound-private-session-mining](skills/approval-bound-private-session-mining/SKILL.md): Extract source-labeled, minimized findings from an approved private transcript set while retaining scope, redaction, uncertainty, and revocation evidence. Specialist of eternities-mnemosyne.
- [eternities-mnemosyne](skills/eternities-mnemosyne/SKILL.md): Recover task truth, design durable memory, reduce context, audit retrieval, and maintain reasoned dependency state.
- [knowledge-base-architecture-and-maintenance](skills/knowledge-base-architecture-and-maintenance/SKILL.md): Organize and maintain knowledge collections with audience-led navigation, stable source and claim identities, authority and effective states, bounded reads, versioned derived views, and recoverable retirement. Specialist of eternities-mnemosyne.
- [memory-retention-and-recovery](skills/memory-retention-and-recovery/SKILL.md): Retain and recover minimal task-critical decisions, evidence pointers, freshness, conflicts, and safe next actions.
- [retrieval-grounded-answering](skills/retrieval-grounded-answering/SKILL.md): Build and test retrieval-grounded answers with evidence citations, permission filters, freshness and measured context cost. Specialist of eternities-mnemosyne.

## models

- [eternities-hephaestus](skills/eternities-hephaestus/SKILL.md): Qualify model, runtime, hardware, and serving choices against matched quality, capacity, operational, privacy, license, and cost evidence.
- [experiment-artifact-lineage](skills/experiment-artifact-lineage/SKILL.md): Verify model training checkpoint lineage, dataset splits and cached feature dependencies before reuse, resume, warm-start or reproducibility claims. Specialist of eternities-hephaestus.

## release

- [eternities-herald](skills/eternities-herald/SKILL.md): Turn repository evidence into release plans, readiness decisions, dependency checks, graph correctness, and reproducible package artifacts.
- [infrastructure-plan-apply-isolation](skills/infrastructure-plan-apply-isolation/SKILL.md): Isolate infrastructure tests and plans from authorized state-changing applies, preserving version, state, diff, and cleanup evidence. Specialist of eternities-herald.
- [performance-release-gating](skills/performance-release-gating/SKILL.md): Compare a candidate with a declared baseline under repeatable workload, variance, resource, functional, and release-readiness gates. Specialist of eternities-herald.
- [release-script-safety](skills/release-script-safety/SKILL.md): Harden release procedures with effect inventories, preflight checks, dry-run, idempotent state, interruption recovery, rollback, and noninteractive failure evidence. Specialist of eternities-herald.

## research

- [eternities-oracle](skills/eternities-oracle/SKILL.md): Investigate consequential local, authoritative, and hybrid questions with reproducible source ledgers, conflict handling, and bounded conclusions.

## science

- [counterbalanced-agent-evaluation](skills/counterbalanced-agent-evaluation/SKILL.md): Compare raw and skill-enabled agents using isolated conditions, blinded counterbalanced review, held-out tasks and quality-cost evidence. Specialist of eternities-athena.
- [diagnostic-statistical-model-inference](skills/diagnostic-statistical-model-inference/SKILL.md): Diagnose fit, assumptions, influence, uncertainty, and specification sensitivity before making descriptive, predictive, or causal claims. Specialist of eternities-athena.
- [ecological-sampling-and-detection-uncertainty](skills/ecological-sampling-and-detection-uncertainty/SKILL.md): Audit ecological sampling, event and effort records, imperfect detection and reporting-support uncertainty before occupancy, abundance or change claims. Specialist of eternities-athena.
- [eternities-athena](skills/eternities-athena/SKILL.md): Appraise claims and studies through design validity, bias, confounding, statistical inference, causal limits, and calibrated uncertainty.
- [genomic-coordinate-assembly-and-variant-gates](skills/genomic-coordinate-assembly-and-variant-gates/SKILL.md): Bind genomic coordinate and variant transformations to assemblies, contigs, orientation, normalization rules, mapping provenance, and explicit rejection gates. Specialist of eternities-athena.
- [interatomic-model-validation](skills/interatomic-model-validation/SKILL.md): Assess material-specific evidence for one learned interatomic-potential use through consistent references, domain-aware partitions, and claim-relevant property checks. Specialist of scientific-surrogate-validation.
- [landscape-connectivity-analysis](skills/landscape-connectivity-analysis/SKILL.md): Analyze habitat connectivity and corridor assumptions with explicit patch, resistance, graph and movement-threshold sensitivity evidence. Specialist of eternities-athena.
- [molecular-observable-integrity](skills/molecular-observable-integrity/SKILL.md): Check molecular trajectory observables for atom identity, periodic-coordinate interpretation, equilibration and correlation-aware uncertainty before reporting results. Specialist of physics-constrained-numerical-validation.
- [physics-constrained-numerical-validation](skills/physics-constrained-numerical-validation/SKILL.md): Validate numerical models through dimensional checks, invariants, limiting cases, convergence, stability, and independent references with explicit uncertainty boundaries. Specialist of eternities-athena.
- [scientific-surrogate-validation](skills/scientific-surrogate-validation/SKILL.md): Validate scientific surrogate claims using decision-time-available features, leakage-resistant grouped evaluation, matched baselines, separately fitted uncertainty calibration, and complete adaptive-pool accounting. Specialist of eternities-athena.
- [symbolic-mathematics-python](skills/symbolic-mathematics-python/SKILL.md): Perform assumption-aware symbolic derivations in Python with domain, unit, branch, singularity, and independent numerical cross-check evidence. Specialist of eternities-daedalus.

## security

- [dependency-supply-chain-integrity](skills/dependency-supply-chain-integrity/SKILL.md): Reconcile consumed dependency artifacts, lockfile drift, inventory coverage, provenance and exposure, then verify bounded repairs. Specialist of eternities-aegis.
- [eternities-aegis](skills/eternities-aegis/SKILL.md): Evidence-linked security, trust-boundary, authority, workflow, and residual-risk decisions.

## social

- [eternities-chorus](skills/eternities-chorus/SKILL.md): Create evidence-led communication, editorial, community, measurement, and share-preview artifacts with identity and access intact.
- [interpersonal-understanding-and-dialogue](skills/interpersonal-understanding-and-dialogue/SKILL.md): Clarify interpersonal meaning and prepare respectful dialogue by separating observed evidence from tentative interpretations.

## writing

- [docx-package-redline-and-render-verification](skills/docx-package-redline-and-render-verification/SKILL.md): Edit DOCX packages with minimal relationship-safe changes and verify review markup, package integrity, external targets, and rendered pagination. Specialist of eternities-logos.
- [eternities-logos](skills/eternities-logos/SKILL.md): Create precise technical, editorial, documentation, reporting, narrative, extraction, and structural-review artifacts from supplied evidence.
- [narrative-structure-and-revision](skills/narrative-structure-and-revision/SKILL.md): Write and revise fiction through particular desires, scene turns, voice and imagery, preserving canon, reader promise, and consequential interactive states. Specialist of eternities-logos.
- [voice-style-calibration](skills/voice-style-calibration/SKILL.md): Infer and apply an evidence-based written voice across contexts while preserving meaning, attribution, and register distinctions. Specialist of eternities-logos.
