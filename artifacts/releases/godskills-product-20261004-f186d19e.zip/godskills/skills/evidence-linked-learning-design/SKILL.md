---
name: evidence-linked-learning-design
description: Design evidence-linked lessons, assessments, teaching handoffs and learner reports from observable goals and supplied achievement evidence.
---

# Evidence-linked learning design

Turn a lesson, course unit, or workplace training request into a learning experience whose success can be observed. Prefer a usable teaching artifact over a long description of pedagogy.

For a substitute-facilitator handoff or learner report, read [handoffs and reporting](references/handoffs-and-reporting.md). These use existing evidence and plans; do not rebuild a course just to prepare a day's cover notes or draft a comment.

When learners need to manipulate a bounded model to test a specific prediction or misconception, use [educational microsimulation](references/educational-microsimulation.md). It adds explicit state, units, transitions, invariants, replay and probability checks. Do not load it for ordinary lesson plans or reporting; prefer a static example when interaction adds no useful causal feedback.

## Start from the learner and the evidence

For a learner-controlled change to one optional instructional aid across sessions, use [support choices and safe resumption](references/support-transition.md). Protected access remains available; instructional evidence, learner binding and save outcomes stay separate. This method is not required for ordinary lessons and does not create a learner profile or authorize record retention.

Recover the topic, audience, duration, prerequisites, teaching setting, available materials and accessibility needs from context. Ask only for missing details that would change the design. If a curriculum or credential standard matters, use the supplied authoritative version or retrieve the current official source. Record its jurisdiction and version; never manufacture standard identifiers. Without verified standards, provide a useful provisional lesson and mark alignment unverified.

Write the smallest set of outcomes the requested lesson or unit needs, as actions a learner can demonstrate. Decide what evidence would show each outcome before selecting activities. Match the challenge to the outcome: recognition questions do not establish the ability to design, explain or troubleshoot.

## Build the experience

1. When prerequisite understanding is unknown or could change the lesson, use a brief diagnostic and specify what changes if it reveals a gap. Reuse current supplied evidence when sufficient.
2. Sequence explanation, a worked example or investigation, supported practice, and independent application. Choose the sequence for the content; do not force one teaching ideology onto every subject.
3. Make the important reasoning visible in the example. Include a plausible wrong answer and a prompt that helps distinguish the misconception from a careless error.
4. Offer scaffolds and extensions when learner variation or the task calls for them, while providing equivalent accessible participation. Keep access accommodations available; only optional instructional aids can be reduced, with an appropriate learner choice and restore path. Preserve intellectual challenge when changing presentation or response format.
5. Budget the full time, including transitions, setup and reflection. List actual materials and a low-resource fallback. Avoid a plan that requires an unprovided account or paid classroom service.
6. Give the facilitator a check-for-understanding point and a concrete decision: advance, revisit with a different representation, or give targeted practice.

## Deliver and validate

Return the learner-facing goal, success criteria, timed sequence, facilitator cues, practice task, assessment with scoring guidance, supports and extension. For a course, add a prerequisite map and a cumulative assessment rather than repeating isolated lessons.

Check that every goal is practiced and assessed, and that every assessment has a defensible expected answer or rubric. Audit language load, contrast, captions, keyboard access and equivalent participation where relevant. Avoid collecting identifiable student data unless needed and authorized.

Example: if the goal is to compare two explanations using evidence, a vocabulary quiz alone is insufficient. Give a short unfamiliar example, ask the learner to choose and justify an explanation, and score the quality of the evidence link.

A well-designed plan is not evidence that learning occurred. After teaching, compare actual learner work with the criteria and revise the missed mechanism. Do not infer ability, disability or motivation from a single response.
