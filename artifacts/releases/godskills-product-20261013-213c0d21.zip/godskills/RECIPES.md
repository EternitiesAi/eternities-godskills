# Use several skills without loading the library

These are examples of composition, not mandatory stages. Select a method only
when it resolves a current uncertainty. A task that needs one specialist should
not pay for an entire orchestration stack.

## From idea to a working product

User: "Build a booking tool for my repair shop. Customers should pick available
times, staff should avoid double bookings, and I need to know whether it helps."

1. **Prometheus**: identify the customer job, the smallest useful workflow, the
   business assumption, and an acceptance test. Do not invent market evidence.
2. **Architect**: settle the few consequential decisions: who owns availability,
   how concurrent bookings are serialized, which data is retained, and how a
   failed payment or notification recovers. Skip a grand architecture document.
3. **Daedalus** plus **Muse** as needed: build a thin end-to-end slice; implement
   booking behavior, useful errors, keyboard access, mobile states, and a clear
   visual identity. Test the double-booking race, not only the happy screenshot.
4. **Herald** when release is requested: check reproducibility, migration,
   observability, rollback, and the actual environment. Carry out deployment only
   within the user's authorized account and scope.
5. Return the functioning artifact, verification results, outstanding risks, and
   the agreed measure of usefulness. A published page is not proof of demand.

Forge can coordinate a long version of this task; it is unnecessary for a short
implementation. Each handoff carries only the decision, relevant files, and
acceptance conditions, not the full preceding conversation.

## From an incident to a verified repair

User: "Payments timed out, then some customers were charged twice. Fix it."

**Phoenix** reconstructs the commit/timeout timeline and tests a specific
hypothesis. **API rate-limit recovery** handles only the retry boundary: uncertain
commit status, stable idempotency keys, cancellation, deadlines and concurrency.
**Invariant guard** helps construct a small independent oracle for "at most one
charge per intent." Aegis joins if the trace reveals leaked credentials or an
authority boundary; it is not loaded simply because payments are mentioned.

The output is a repair with regressions and an explicit account of external
actions. Test transactions, real refunds, and customer messages have different
effects; permission for code repair does not imply all three.

## From research to a clear public explanation

User: "Compare these studies and write a readable article about what they show."

**Oracle** finds and cites the primary material. **Athena** evaluates confounding,
uncertainty, effect sizes and disagreements. **Logos** turns the supported result
into a compelling narrative without converting inference into fact. The article
keeps limitations close to consequential claims. A specialist statistical skill
is loaded only if the task requires reanalysis, not merely because numbers occur.

## From a visual idea to a playable scene

User: "Make a mysterious floating garden that I can orbit and explore."

**Muse** develops one visual direction with readable composition, depth, motion
and budget. **Arcadia** handles camera behavior, interaction, spatial performance
and playability. The agent first builds something viewable, then tests orbit,
near/far clipping, resize, reduced motion and a slower device tier. Visual review
can reject a technically correct result that lacks the intended experience.

No recipe guarantees that skill use beats a raw model. Preserve spontaneous
solutions and use the methods to solve observed gaps, not to replace creativity
with process.

## From model answers to a dependable integration

User: "Extract records from these documents and feed our application, but make
missing evidence and outages visible."

**Structured output contracts** defines the consumer's schema and source-bound
meaning, preserves abstention and tests malformed, stale and incomplete replies.
**Hermes** owns the adapter, timeouts, permitted effects and truthful degraded
mode. **Retrieval-grounded answering** joins only if document retrieval itself
needs work. **Forge** may coordinate a bounded critique/revision loop, but a model
reviewer's approval cannot replace validation or authorize downstream writes.

## From a distinctive voice to an original concept

User: "Use my supplied writing as a reference, but make this new product story
feel imaginative rather than like an imitation of the examples."

[Voice-style calibration](skills/voice-style-calibration/SKILL.md) identifies
reusable voice characteristics and where a new audience changes the register.
[Imaginative concept development](skills/imaginative-concept-development/SKILL.md)
explores different mechanisms and experiences, then develops a chosen direction.
Logos joins only when the actual drafting or editorial task needs its source and
artifact work. Keep fictional imagery distinct from factual product claims.

The result is a new concept draft with inspectable style decisions, not a claim
of global novelty, a perfect voice profile or proven creative quality.

## From a tense exchange to a useful next conversation

User: "These teammates disagree. Help me understand what each actually asked
for and draft a response that moves the discussion forward."

[Interpersonal understanding and dialogue](skills/interpersonal-understanding-and-dialogue/SKILL.md)
separates statements from inferred motives, identifies a useful clarification
and drafts a response proportionate to the conflict. Preserve uncertainty without
turning every sentence into hedging. This is neither diagnosis nor a strategy for
coercing someone. Chorus joins if the task becomes a wider communication system;
one private reply does not require that stack.

## From interrupted work to a complete deliverable

User: "Finish this approved project over several sessions. Don't lose the
requirements or repeat a job that might already have completed."

[Long-horizon work continuity](skills/long-horizon-work-continuity/SKILL.md)
preserves the objective, milestone state, ownership, authority and uncertain
effects. [Memory retention and recovery](skills/memory-retention-and-recovery/SKILL.md)
joins when durable retention or stale/conflicting retrieval is the actual
problem. [Completeness and consistency audit](skills/completeness-and-consistency-audit/SKILL.md)
checks the requested deliverable against its obligations and artifact evidence
instead of measuring success by its length.

Use Forge when implementation needs multi-stage coordination, not as a mandatory
wrapper around every turn. A host must provide any real multi-day runner; a
retained checkpoint alone is not evidence that work is active. Perform already
authorized work when its prerequisites hold, and preserve stop/pause conditions
without inventing a fresh permission request for each milestone.
